Resources I used:

https://ccle.ucla.edu/pluginfile.php/4327283/mod_resource/content/0/project_discussion_recap.pdf

https://www.tutorialspoint.com/java/java_files_io.htm

https://beginnersbook.com/2014/01/how-to-read-file-in-java-bufferedinputstream/

https://docs.oracle.com/javase/7/docs/api/java/security/MessageDigest.html

https://docs.oracle.com/javase/7/docs/api/java/io/BufferedInputStream.html

https://docs.oracle.com/javase/7/docs/api/java/io/FilterInputStream.html#read(byte[])

https://stackoverflow.com/questions/19561167/buffer-size-for-bufferedinputstream
