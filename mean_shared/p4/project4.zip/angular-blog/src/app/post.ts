// Adapted from project 4 spec: http://oak.cs.ucla.edu/classes/cs144/project4/
// Blog post class
export class Post {
    postid: number = 0;
    created: number = 0;
    modified: number = 0;
    title: string = "";
    body: string = "";
};